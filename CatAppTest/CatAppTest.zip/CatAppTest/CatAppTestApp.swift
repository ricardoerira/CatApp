//
//  CatAppTestApp.swift
//  CatAppTest
//
//  Created by andres on 4/04/25.
//

import SwiftUI

@main
struct CatAppTestApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
