//
//  UserDefaultsKeys.swift
//  CatAppTest
//
//  Created by andres on 4/04/25.
//

import Foundation

struct UserDefaultsKeys {
    static let favoritesKey = "favoriteCatIDs"
}
